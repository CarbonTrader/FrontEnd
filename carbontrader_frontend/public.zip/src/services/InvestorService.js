let data;

const getData = async () => {};

export default getData;
